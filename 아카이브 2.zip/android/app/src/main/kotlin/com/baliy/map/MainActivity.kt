package com.baliy.map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
