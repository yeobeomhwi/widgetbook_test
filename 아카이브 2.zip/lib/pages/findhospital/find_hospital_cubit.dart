import 'dart:convert';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:map/component/hospital_bottom_sheet.dart';
import 'package:map/model/place.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:xml2json/xml2json.dart';
import '../../service/place_api.dart';

part 'find_hospital_state.dart';

part 'find_hospital_cubit.freezed.dart';

@injectable
class FindHospitalCubit extends Cubit<FindHospitalState> {
  FindHospitalCubit() : super(FindHospitalState());

  final ApiService apiService = ApiService();
  late NaverMapController? naverMapController;
  Set<NClusterableMarker> markers = {};

  void showSearchList() => emit(state.copyWith(showSearchBar: true));

  void hideSearchList() => emit(state.copyWith(showSearchBar: false));

  // 병원 검색
  void searchHospital(String searchHospitalName) async {
    if (searchHospitalName.isEmpty) return;

    emit(state.copyWith(searchHospitalName: searchHospitalName));

    try {
      final hospitalsXml =
          await apiService.getPlaces(query: searchHospitalName);

      final myTransformer = Xml2Json();
      myTransformer.parse(hospitalsXml);
      final json = jsonDecode(myTransformer.toOpenRally());

      final items = json['response']['body']['items']['item'];
      final List<Place> placeList = items is List
          ? items.map<Place>((item) => Place.fromJson(item)).toList()
          : [Place.fromJson(Map<String, dynamic>.from(items))];

      emit(state.copyWith(hospitals: placeList));

      showSearchList();
      markHospitalsOnMap();
    } catch (e) {
      print('병원 검색 중 오류 발생: $e');
    }
  }

  // 마커를 클릭하면 moveCamera를 호출하도록 수정
  void markHospitalsOnMap() {
    naverMapController?.clearOverlays();
    const double offset = 0.00005;

    for (var hospital in state.hospitals) {
      double latitude = double.parse(hospital.YPos);
      double longitude = double.parse(hospital.XPos);

      // 기존 마커가 같은 위치에 있다면 살짝 이동
      if (markers.any((marker) =>
          marker.position.latitude == latitude &&
          marker.position.longitude == longitude)) {
        longitude += offset;
      }

      final marker = NClusterableMarker(
        icon: NOverlayImage.fromAssetImage('assets/images/map_hospital_sm.png'),
        id: hospital.yadmNm,
        position: NLatLng(latitude, longitude),
      )..setOnTapListener((marker) {
          // 마커 클릭 시 moveCamera 실행
          cb.call(hospital);
          moveCamera(hospital);
        });

      markers.add(marker);
    }

    naverMapController?.addOverlayAll(markers.toSet());
  }

  late Function(Place) cb;

  void setCallback(Function(Place) cb) {
    this.cb = cb;
  }

  // 마커 클릭시 카메라 이동
  void moveCamera(Place hospital) {
    emit(state.copyWith(selectName: hospital));
    print(state.selectName);

    naverMapController?.updateCamera(
      NCameraUpdate.scrollAndZoomTo(
        target: NLatLng(
          double.parse(hospital.YPos),
          double.parse(hospital.XPos),
        ),
        zoom: 17,
      ),
    );
    //검색목록 숨기기
    hideSearchList();
  }
}
