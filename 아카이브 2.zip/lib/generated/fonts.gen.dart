/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class Fonts {
  Fonts._();

  /// Font family: NanumSquareRound
  static const String nanumSquareRound = 'NanumSquareRound';

  /// Font family: Roboto
  static const String roboto = 'Roboto';
}
