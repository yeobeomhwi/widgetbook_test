import 'package:flutter/material.dart';

const bg = Color(0xFFF9F5EE);
const vaccineNameColor = Color(0xFF7A5B5B);
const tintRed = Color(0xFFE37B7B);